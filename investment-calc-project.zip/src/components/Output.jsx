import React from 'react'
import { calculateInvestmentResults } from '../util/investments';

const Output = () => {
}

export default Output
