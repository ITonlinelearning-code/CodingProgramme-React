import React from 'react'
import logo from '../assets/logo.jpg'

const Header = () => {
  return (
    <header id="header">
    </header>
  )
}

export default Header
