import React from 'react'
import '../App.css'

const UserInput = () => {
  return(
    <section>
        
    </section>
  ) 
}

export default UserInput